<?php

if ( function_exists( 'add_image_size' ) ) {
	add_image_size( 'shb-thumbnail-1', 1180, 710, true );
	add_image_size( 'shb-thumbnail-2', 460, 300, true );
	add_image_size( 'shb-thumbnail-3', 124, 124, true );
}


?>